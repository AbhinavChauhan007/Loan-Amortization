package com.springboot.LoanAmortization.dto;

import java.util.ArrayList;
import java.util.List;

public class LoanScheduleResponse {
	protected double principal;
	protected int numberOfEMIs;
	protected double totalAmountPaid;
	protected double totalInterestPaid;
	protected double totalPrepayment;
	protected double preClosureCharge;
	protected List<LoanSchedule> LoanSchedule = new ArrayList<LoanSchedule>();
	protected List<RateOfInterest> rateOfInterests = new ArrayList<RateOfInterest>();
	
	
	
	public LoanScheduleResponse() {
		this.principal = 0;
		this.numberOfEMIs = 0;
		this.totalAmountPaid = 0;
		this.totalInterestPaid = 0;
		this.totalPrepayment = 0;
		this.preClosureCharge = 0;
		this.LoanSchedule = null;
		this.rateOfInterests = null;
		
	}
	public LoanScheduleResponse(double principal, int numberOfEMIs, double totalPayment, double totalInterestPaid,
			double totalPrepayment, double preClosureCharge, List<LoanSchedule> loanSchedule, List<RateOfInterest> rates) {
		super();
		this.principal = principal;
		this.numberOfEMIs = numberOfEMIs;
		this.totalAmountPaid = totalPayment;
		this.totalInterestPaid = totalInterestPaid;
		this.totalPrepayment = totalPrepayment;
		this.preClosureCharge = preClosureCharge;
		this.LoanSchedule = loanSchedule;
		this.rateOfInterests = rates;
		
	}
	public double getPrincipal() {
		return principal;
	}
	public void setPrincipal(double principal) {
		this.principal = principal;
	}
	public int getNumberOfEMIs() {
		return numberOfEMIs;
	}
	public void setNumberOfEMIs(int numberOfEMIs) {
		this.numberOfEMIs = numberOfEMIs;
	}
	
	public double getTotalAmountPaid() {
		return totalAmountPaid;
	}
	public void setTotalAmountPaid(double totalAmountPaid) {
		this.totalAmountPaid = totalAmountPaid;
	}
	public double getPreClosureCharge() {
		return preClosureCharge;
	}
	public void setPreClosureCharge(double preClosureCharge) {
		this.preClosureCharge = preClosureCharge;
	}
	public double getTotalInterestPaid() {
		return totalInterestPaid;
	}
	public void setTotalInterestPaid(double totalInterestPaid) {
		this.totalInterestPaid = totalInterestPaid;
	}
	public List<LoanSchedule> getLoanSchedule() {
		return LoanSchedule;
	}
	public void setLoanSchedule(List<LoanSchedule> loanSchedule) {
		LoanSchedule = loanSchedule;
	}
	public double getTotalPrepayment() {
		return totalPrepayment;
	}
	public void setTotalPrepayment(double totalPrepayment) {
		this.totalPrepayment = totalPrepayment;
	}
	public List<RateOfInterest> getRateOfInterests() {
		return rateOfInterests;
	}
	public void setRateOfInterests(List<RateOfInterest> rateOfInterests) {
		this.rateOfInterests = rateOfInterests;
	}
	
	
	
	
	
}