package com.springboot.LoanAmortization.dto;

public enum RoundingDirection {
		ROUND_UP, ROUND_DOWN, TRUNCATE
}
