/**
 * 
 */
package com.springboot.LoanAmortization.dto;

/**
 * 
 */
public enum PaymentUnit {
	DAILY, WEEKLY, BI_WEEKLY, QUARDRA_WEEKLY, SEMI_MONTHLY, MONTHLY, THIRTY_DAY_MONTH, BI_MONTHLY, QUARTERLY, HALF_YEARLY, YEARLY

}
