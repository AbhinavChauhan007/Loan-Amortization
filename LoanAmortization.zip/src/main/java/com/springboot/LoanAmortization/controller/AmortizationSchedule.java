package com.springboot.LoanAmortization.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.LoanAmortization.dto.LoanScheduleRequest;
import com.springboot.LoanAmortization.dto.LoanScheduleResponse;
import com.springboot.LoanAmortization.dto.LoanSchedule;
import com.springboot.LoanAmortization.dto.RateOfInterest;
import com.springboot.LoanAmortization.helper.AmortizationHelper;

@RestController
public class AmortizationSchedule {

	@Autowired
	AmortizationHelper helper;

	@PostMapping("/getLoanSchedule")
	public LoanScheduleResponse LoanSchedule(@RequestBody(required = false) LoanScheduleRequest params) {
		List<LoanSchedule> scheduleList = helper.getAmortizationSchedule(params);
		List<RateOfInterest> rates = new ArrayList<>();
		double netPayment;
		double netInterestPaid = 0;
		double netPrepayment = 0;
		int startTerm = 1;
		double roi = params.getRoi();
		Optional<LoanSchedule> lastRecord = scheduleList.stream().filter(loanSchedule -> loanSchedule.getPreClosureCharge() > 0).findFirst();
		double preClosureCharge = lastRecord.map(LoanSchedule::getPreClosureCharge).orElse(0.0);
		for (int i = 0; i < scheduleList.size(); i++) {
			netPrepayment += scheduleList.get(i).getPrepaymentAmount();
			netInterestPaid += scheduleList.get(i).getInterestPaid();
			if (roi != scheduleList.get(i).getRateofInterest()) {
				rates.add(new RateOfInterest(startTerm, i, roi));
				startTerm = i + 1;
				roi = scheduleList.get(i).getRateofInterest();
			}
		}
		if (startTerm <= scheduleList.size()) {
			rates.add(new RateOfInterest(startTerm, scheduleList.size(), roi));
		}
		netPayment = params.getPrincipal() + netInterestPaid + preClosureCharge;
        return new LoanScheduleResponse(params.getPrincipal(), scheduleList.size(), netPayment,
				netInterestPaid, netPrepayment, preClosureCharge, scheduleList, rates);
	}

	@PostMapping("/getEMI")
	public Double getEMI(@RequestBody(required = false) LoanScheduleRequest params) {
		return helper.roundingEMI(helper.periodicPayment(params.getPrincipal(), params.getRoi(), params.getTerm(), params.getTermUnit(), params.getPaymentFrequency(), params.getStartDate()), params.getRoundingDirection(), params.getRoundTo());
	}
}
